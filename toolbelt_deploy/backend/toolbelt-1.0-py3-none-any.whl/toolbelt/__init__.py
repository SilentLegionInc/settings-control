# to run wia waitress use
# $ waitress-serve --host=0.0.0.0 --port=2021 toolbelt:app
from toolbelt.main import app
